Instructions to have the Mega Pro 3.3V show up in the Arduino device list. 
 
1) Download the latest mega_pro_3.3V zip file and extract it.	
2) You will need to be using a recent version of the Arduino environment, version 18 or later.
3) Create a 'hardware' directory inside your sketches folder. 
4) Copy the mega_pro_3.3V directory into the hardware directory.
5) Restart the Arduino software. New boards will appear in the Tools > Board menu. 
